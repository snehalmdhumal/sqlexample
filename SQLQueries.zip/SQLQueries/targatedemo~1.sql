--19/2/22

create table empinfo1(eid number(7),ename varchar2(25),emob varchar2(14),ecity varchar2(10),edept varchar2(10);
describe empinfo1;
insert into empinfo1 values (101, 'snehal', 9766545454,  'Pune', 'cse');
insert into empinfo1 values (102, 'Advika', 9787545454,  'mum', 'IT');
insert into empinfo1 values (103, 'Shivaji', 8066545454,  'Pune', 'HR');
insert into empinfo1 values (104, 'soham', 9066545454,  'satara', 'IT');
insert into empinfo1 values (105, 'darshan', 9366545454,  'kolhapur', 'Mech');

select * from empinfo1;
select eid,ename,ecity from empinfo1;
select * from empinfo1 where eid=103;
select * from empinfo1 where ename='snehal';
select * from empinfo1 where ename='Snehal';--not run because data is case sensative so o/p not display
select * from empinfo1 where ecity='satara';
select * from empinfo1 where edept='IT';

select eid,edept from empinfo1 where ename ='snehal';
insert into empinfo1 values(106,'VAIBHAV','9809898900','solapur','Pune');
update empinfo1 set ecity='Pune'where eid=106;
insert into empinfo values(151,'VAIBHAV','9809898900',80000,'Pune');

insert into empinfo1 (eid,ename,edept)values(107,'','HR');
insert into empinfo1 (eid,ename,edept)values(108,' ','cse');--using space between single cote display ename blank insted off null

select * from empinfo1;

insert into empinfo1 (eid,ename,edept)values(109,'NULL','HR');--here null consider as name
select * from empinfo1 where edept is null;
select * from empinfo1 where edept is null;
insert into empinfo1 (eid,ename)values(110,'tina');--here null consider as name or string
select * from empinfo1 where ename is null;--display record from ename column whose value null
select * from empinfo1 where ecity is null;
select * from empinfo1 where emob is null;


select * from empinfo where ename= null;--it will not work
select * from empinfo1 where ename='NULL';--display the row who having name=null or null as string
select * from empinfo1 where ename ='';--it will display only table structure not data

--is not null

select * from empinfo1 where ename is not null;--it will not display null value,but it display NULL string and space(eg eid-108,109)
select * from empinfo where edept is not null;
--o/p
eid ename   emob        ecity    dept
102	Advika	9787545454	mum	     IT
103	Shivaji	8066545454	Pune	 HR
104	soham	9066545454	satara	 IT
105	darshan	9366545454	kolhapur Mech
106	VAIBHAV	9809898900	Pune	 Pune
106	VAIBHAV	9809898900	Pune	 Pune
107				HR
108	 			cse
109	NULL			HR
110	tina			

--update command
update empinfo set esal = 125000 where eid=115;

update empinfo1 set ecity='satara' where eid=103;--it will update ecity to satara whose eid 103
update empinfo1 set ecity='nagapur' where ecity='satara';--it will update ecity to nagapur whose ecity is satara 
update empinfo1 set ecity='pune' where eid=107 and ename is null;--it will update ecity to nagapur whose ecity is satara 

select * from empinfo1;
update empinfo1 set emob='9036485692' where eid=110;

select * from empinfo1;

create table empdemo(eid number (3),fname varchar2(10),lname varchar2(10),esal number(10),Incentive number(5),ecity varchar2 (10),edept varchar2(10)); 
insert into empdemo values(101,'tina','Jadhav',70000,1000,'Pune','IT');
drop table empdemo;
insert into empdemo values(102,'snehal','Dhumal',60000,2000,'mum','HR');
insert into empdemo values(103,'darshan','Mane',80000,1500,'Pune','IT');
insert into empdemo values(104,'Harsha','bhosale',90000,1000,'Nagapur','cse');
insert into empdemo values(105,'Anvika','shinde',50000,1500,'Pune','mech');
select * from empdemo;
update empdemo set esal=85000 where fname='tina';
rollback;
update empdemo set esal=85000 where lname='shinde';
rollback;
update empdemo set esal=50000;--update all employee salary with 50000

update empdemo set fname='sonali',ecity='london' where eid=104;--update two value at a time
update empdemo set esal=90000,ecity='mum',edept='cse' where eid=101;--update three value at a time

update empdemo set esal='' where lname='Mane';--update esal to null of mane/delete perticular singal colume value

update empdemo set esal=50000 where esal is null;--update salary whose salary is null
--delete
delete empdemo where eid=105;-- delete single row or record of perticularrecord. rollback possible before commite
delete from empdemo;--delete all record from table but structure as it is
delete empdemo;--it display same o/p as above query

rollback;
select * from empdemo;
insert into empdemo values(106,'','Bosale',60000,1500,'Pune','IT');
delete from empdemo where fname is null;--How to delete null value rows with respect to ename column from your table?
delete empdemo where fname is null;
--SQL Operator
1)Arithmatic oprrator
select (esal+incentive)from empdemo;--addition of two column(sal+incetive}whose data type no.
select (esal+incentive)as total_salary from empdemo;
select eid,fname,lname,esal,incentive,(esal+incentive)as total_salary from empdemo;
select (esal+incentive) "total_salary" from empdemo;
--How to select total columns from table with addition of two columns?
--select * , (esal+eincent) from employee11---It will not run
--empdemo.* display all columns with perticular arithmatic opration
select empdemo.*,(esal+incentive)from empdemo;


select empdemo.*,(esal+incentive)"taotal_salary" from empdemo where eid=103;--display addition of perticular emp record total salary
select (esal+incentive)from empdemo;
select (esal+incentive-1000)from empdemo;

--subtraction
select (esal-incentive)from empdemo;---deducted salary
select (esal-incentive) as Deducted_Salary from empdemo;--
select (esal-1000)as deducted_salary from empdemo;--deducted 1000 rs from salary
select empdemo.*,(esal-incentive) as Deducted_Salary from empdemo;--display all record witn deducted salary
select empdemo.*,(esal-incentive)"taotal_salary" from empdemo where eid=103;
--multiplication
--0.10 increment in incentive
select (incentive*.10)from empdemo;--10%of incentive
select (incentive*1.10)from empdemo;--increse incentive with 10%
select (esal+incentive*1.10)from empdemo;--10% incentive add in sal
select fname,eid,ecity,esal,incentive,(esal+incentive*1.10) as TotalSalary from empdemo;--increase 10% in incentive and add them in salary
select empdemo.*,(esal+incentive*1.10) as TotalSalary from empdemo;--increase 10% in incentive and add them in salary display all col
select empdemo.*,(esal+incentive*1.10) as TotalSalary from empdemo where eid=103;--add  10% add in incentive+esal of perticular employee eg 103 
--division of two col
select 1200000/12 as per_month_salary from dual;
select empdemo.*,(esal*12)/12 as per_month_salary from empdemo;
select empdemo.*,(esal/eincent) as TotalSalary from employ where eid=103;
--comparision operator =,<,<=,>,>=
select * from empdemo;
select * from empdemo where esal = 50000;
select * from empdemo where esal = 80000;--display empty table if salary not match
select * from empdemo where esal != 50000;--it display whose salary not equal to 50000
select * from empdemo where esal < 90000;--it display whose salary less than 90000
select * from empdemo where esal <= 50000;--it display whose salary less than or equal to 50000
select * from empdemo where esal > 50000;--it display whose salary grater than 50000
select * from empdemo where esal >= 60000;--it display whose salary grater than or equal to 60000
select * from empdemo where fname = 'Anvika';--It display fname Anvika
select * from empdemo where fname = 'anvika';--it will not display anvika because it is case sensative so A and a is differnt
select * from empdemo where fname != 'anvika';--it display those record whose nm not anvika

--Between Operator---- It displays the possible range of values from column. It applies on Numeric and date values.
select * from empdemo where esal between 70000 and 90000;--it display salary between 70000 and 90000.eg 70,80,85,etc
select * from empdemo where esal not between 70000 and 90000;--it display salary not between 70000 and 90000

In operator -----It displays the perticular set of values from column. It applies on Numeric,alphabets and date values
select * from empdemo where esal in (90000,50000,70000);--it display whose salary is 90,50,70

select * from empdemo where fname in ('tina','anvika','sonali');--it display record whose name tina,sonali,anvika 
--not in
select * from empdemo where esal not in (90000,50000,70000);
select * from empdemo where fname not in ('tina','anvika','sonali');

--3.concatination operator
--3. Concatinition---||---It combines the values of 2 columns.
select first_name||Last_name from empdemo;
select fname||lname from empdemo;--combine two valuves fname and lname
select fname||'   '||lname from empdemo;
select eid,fname,lname ,fname||'  '||Lname from empdemo;
--how to concate first name and last name from table
-----Citius Tech ques--how to combine 2 columns?
select empdemo.*, fname||Lname from empdemo;
select empdemo.*, fname|| '_' || Lname as FullName from empdemo;--wihout bracket display all record with full name alise
select empdemo.*, (fname|| '_' || Lname) as FullName from empdemo;--with bracket display all record with fullname alise
select first_name||last_name||ccity||cid from Cred_emp_regi
select fname||lname||ecity||eid from empdemo;--combine values of 4 col
select fname||'_'||lname||'_'||ecity||'_'||eid from empdemo;--combine values of 4 col
select (esal || ' ' ||incentive) from empdemo;

select * from empdemo;

--LOgical Operator
--And Or Not
--And
T T T
T F F
F T F
F F F

select * from empdemo where fname='tina' and eid= 121;--record not dispaly because one condition satisfied and 2nd false
select * from empdemo where fname='tina' and eid=101;--it display record because both (name and eid) condition are true 
select * from empdemo where fname='darshan' and esal=50000 and eid=103 and edept= 'IT';--it shows record all condition true
select * from empdemo where fname='darshan' and esal=50000 and eid=104 and edept= 'IT';--3condition true and 1 false so does not display record

--Or
i1 i2 o/p
T T T
T F T
F T T
F F F
select * from empdemo where fname='tina' or eid= 102;--
select * from empdemo where fname='tina' or eid=101;--
select * from empdemo where fname='mona' or eid=111;

select * from empdemo where fname='darshan' or esal=50000 or eid=103 or edept= 'IT';--it shows record all condition true
select * from empdemo where fname='darshan' or esal=50000 or eid=104 or edept= 'IT';--3condition true and 1 false so does not display record

select * from empdemo where fname='sonali' or  esal=50000 or eid=103 and edept= 'IT';--and ni tyachya adicha ani nantarch col chk karto
--Not
select * from empdemo where not(esal=50000);--it display other than 50000
select * from empdemo where not(esal!=50000);--it display 
insert into empdemo values(106,'nilam','korade','',500,'mum','cse');
select * from empdemo;
select * from empdemo where (esal is null);--it dispaly whose sal is null
select * from empdemo where not(esal is null);---- Want to display emp salaries who has not null
select * from empdemo where not (esal is not null);--emp sal whoes value is null
select * from empdemo where esal is null; --alternate query for above question i.e. emp sal whoes 

----I want salaries other than 80000.
select * from empdemo where not(esal=90000);
select * from empdemo where esal!=90000;
select * from empdemo where esal not in (90000);
--chk karne ithun
select * from empdemo where (eid=101 and esal =50000) or ( eid=103);
select * from empdemo where (esal=50000 and eid=102) or (eadd ='Mum' and eid =102);
select * from empinfo where ename='Amit' or eid=102 and eadd ='Mum' or eid =121;
select * from empinfo where ename='Amit' or (eid=102 and eadd ='Mum') or eid =121;
select * from empinfo where ename='Amit' or (eid=102 and eadd ='Mum') or eid =121;
select * from empinfo where ename='Amit' or (eid=102 and eadd ='Mum') or eid =121;

select * from empdemo where fname='Anvika' or (eid=102 and ecity='mum') or eid=103
select * from empdemo where fname='Anvika' or (eid=102 and ecity='pune') or eid=103

select * from empdemo where fname='Anvika' or eid=102 and ecity ='Mum' or eid =103;
-----chk karane ithparyant
select * from empdemo where esal is  null;
select * from empdemo where esal is not null;

--Like Operator----Most of the companies will ask question on like operator.It is used for pattern/String search. It is case sensitive.
--There are 2 wild card keys.
--1. %---unknown length of string
--2. _ ---- One Unknown character.
select * from empdemo;
select * from empdemo where fname like 'A%';--dispaly record whose name starting with A
select * from empdemo where fname like 'n%';--
select * from empdemo where fname like '%n';--display whose name end with n
select * from empdemo where fname like '_i%';--display whose name 2nd character i
select * from empdemo where fname like '%a_';--2nd last character a 
select * from empdemo where fname like '__r%';--3rd last character r 
select * from empdemo where fname like '%a__';--3rd last character a 
select * from empdemo where fname like '_____';--display 5 character string (5 underscore) 
select * from empdemo where fname like '%a%';--display those name which contain a 
select * from empdemo where fname like '%t%' or fname like '%o%';--using or
Select * from empdemo where fname like 's%i' ;--it display whose name starts with s and ends with i
Select * from empdemo where fname like 's%' or fname like '%m' ;--it display whose name starts with s and ends with m

--SQL constraint
SQL Constraints-- applying some rules while data insertion by user.
Primary Key---- it does not accept duplicate and null values in resp column.
each record will be uniquely identified.
Any table has only one primary key constraint.
accept unique and not null values.
combination of unique and not null constraints.(Unique+Not null)



create table emppk (cid number(7) primary key,cname varchar2(20),cmob varchar2(14),cbill number(5),ccity varchar2(20));

insert into emppk values(101,'Amit',98787887,800,'Pune');

insert into emppk values(102,'Amit',98787887,800,'Pune');

insert into emppk values(101,'Sachin',98787887,800,'Pune');--it can not insert duplicate cid
insert into emppk values(103,'Sachin',98787887,800,'Pune');
insert into emppk (cname,cmob,cbill,ccity) values('Riya',898988,900,'Delhi');--it can not insert null value
select * from emppk;

2. Unique---It does not accept duplicate value but accepts null values.

Unique constraints can be applied more than 1 times in a table.
It will accepts any no of null values.
create table empunique (cid number(7),cname varchar2(20),cmob varchar2(14) unique,cbill number(5), ccity varchar2(20));
insert into empunique values(101,'Amit',98787887,800,'Pune');
insert into empunique values(102,'Amit',988887887,800,'Pune');
insert into empunique values(103,'Priya',98787887,1000,'Delhi');--it will not accept duplicate value
insert into empunique (cid,cname,cbill,ccity) values(103,'Amit',800,'Pune');--it accept null value
insert into empunique (cid,cname,cbill,ccity) values(101,'abhi',800,'Pune');
insert into empunique (cid,cname,cbill,ccity) values(105,'abhi',800,'Pune');

select * from empunique;
3. Not null-- It does not accept nulls value but accepts duplicates.
It can be applied on more than 1 column on any table.
create table empnull(cid number(7),cname varchar2(20) not null,cmob varchar2(14),cbill number(5), ccity varchar2(20));
insert into empnull values(101,'Amit',98787887,800,'Pune');
insert into empnull values(101,'Priya',98787887,1000,'Delhi');
insert into empnull (cid,cmob,cbill,ccity) values(103,9876765,800,'Pune'); --not accepts null
insert into empnull (cid,cbill,ccity) values(104,800,'Pune');-- not accepts null
insert into empnull values(101,'Amit',98787887,800,'Pune');--accept duplicate
insert into empnull values('','priya','','','');

select * from empnull;

--all constraint in one table
create table empall (cid number(7) primary key,cname varchar2(20) ,cmob varchar2(14) 
unique not null,cbill number(5), ccity varchar2(20));--we can give two constraint on single column
insert into empall values(101,'Amit',98787887,800,'Pune');
insert into empall values(102,'Amit',98087887,800,'Pune');
insert into empall values(103,'Amit',98087887,800,'Pune');--- Not accepts duplicate record
insert into empall(cname,cmob,cbill,ccity) values('Amit',78087887,800,'Pune'); --not accepts--cid should not be null value as pk was applied.
insert into empall(cid,cname,cbill,ccity) values(104,'Yusuf',800,'Pune');--not accept null value for mob

--chk constraint
4. Check--- It validates the given condtition before data insertion by user. It accepts duplicate and 
   null values until if condition is satisfied.
   It can be applied on more than 1 column on any table.
create table empchk (cid number(7),cname varchar2(20) ,cmob varchar2(14),cbill number(5) check (cbill > 500), ccity varchar2(20));
insert into empchk values(101,'Amit',98787887,501,'Pune');
insert into empchk values(101,'Amit',98787887,1000,'Pune');
insert into empchk values(101,'Amit',98787887,500,'Pune');--not accept 500>500 false
insert into empchk values(103,'riya',88787887,100,'Delhi'); not accepts less than 500
insert into empchk (cid,cbill,ccity) values(103,499,'Pune');--less than 500
insert into empchk (cid,cbill,ccity) values(103,502,'Pune');--accepted null
insert into empchk (cid,cname,ccity) values(104,'abhi','Pune');--accepted null
insert into empchk(cid,cname) values(105,'abhi');

select * from empchk;

5. Default ----- It applies default value to assigned column.
drop table empdf;
create table empdf
(cid number(7),cname varchar2(20) default 'unknown' ,cmob varchar2(14),cbill number(5),ccity varchar2(20) default 'Unspecified');


insert into empdf values(101,'Amit',98787887,501,'Pune');
insert into empdf values(101,'Priya',98787887,1000,'Delhi');
insert into empdf (cid,cmob,cname,cbill) values(103,99876769,'Yusuf',700);
insert into empdf (cid,cmob,cbill) values(103,99876769,700);

insert into empdf(cid,cname) values(109,'abhi');
insert into empdf values(101,'Amit',98787887,501,'Pune');
insert into empdf(cid) values(109);
insert into empdf values(101,'',98787887,501,'');
--only 2nd way insertion for default constraint not work for 1st way
select * from empdf;

--All Constraints Testing----
create table empac (cid number(7) primary key ,cname varchar2(20) not null ,cmob varchar2(14) unique,cbill number(5) check (cbill>500), ccity varchar2(20) default 'Unknown');
insert into empac values(101,'Amit',98787887,501,'Pune');
insert into empac values(102,'Priya',98787807,510,'Delhi');
insert into empac values(107,'Akash',98789887,590,'Pune');
insert into empac (cid,ccity) values(108,'Pune');---not null
insert into empac values(109,'Priyanka',98789887,590,'Pune');---Unique
insert into empac values(107,'Akshay',986898987,590,'Pune');----PK
insert into empac (cmob,cname,cbill) values('','Yusuf',900);---PK
insert into empac (cid,cmob,cname,cbill) values(104,'','Yusuf',900);--- unique default
insert into empac(cid,cname) values(171,'abhijit');
insert into empac(cid,cname,cbill) values(172,'Abhijit',125);--check constraint (SYSTEM.SYS_C004101) violated
insert into empac values(113,'Pooja',955888987,790,'');
select * from empac;

create table empac1(cid number(7),cname varchar2(20) check (cname='Yusuf') ,cmob varchar2(14) unique not null ,cbill number(5) check (cbill=900) unique,
ccity varchar2(20) default 'Unknown');

insert into empac1 values(101,'Amit',98787887,900,'Pune');
insert into empac1 values(102,'Priya','',900,'Delhi');
insert into empac1 values(102,'Priya',98787887,900,'Delhi');
insert into empac1 values(102,'Yusuf',9900887766,900,'');
select * from empac1;

Composite key---- A primary key which is applied on more than one column is known as Composite key.

create table empcompo (cid number(7),cname varchar2(20),cmob varchar2(14),corder varchar2(20),cbill number(5),ccity varchar2(20),primary key(cid,corder,cbill));
insert into empcompo values(101,'Amit',9878789,'PD',500,'Pune');
insert into empcompo values(101,'Amit',9878789,'Mob',5000,'Pune');
insert into empcompo values(101,'Amit',9878789,'Mob',15000,'Pune');
insert into empcompo values(102,'Amit',9878789,'PD',500,'Pune');
insert into empcompo values(101,'Amit',9878789,'Mob',5000,'Pune');---Unique Const viaolated
insert into CRED7CONSTEST8 values(102,'Amit',9878789,'',500,'Pune');---can not insert Null value
insert into empcompo values(107,'Amit',9878789,'PD','','Pune');
insert into empcompo values('','Amit',9878789,'PD',500,'Pune');
insert into empcompo values('','Amit',9878789,'PD',500,'Pune');
insert into empcompo values(109,'Amit',9878789,'',500,'Pune');
insert into empcompo values(109,'Amit',9878789,'mob','','Pune');
in this table pk apply on 3 col there for we called as composite key.it can not accept null value for any single col.
also can not accept duplicate value at time 3 col(3 clo pan duplicate asatil tar nahi accept karat).but accept two duplicate and one different
select * from empcompo;
-----SQL Functions-----
1.Aggregate Functions
2.Character Functions
3.Date Functions
4.Conversion Function

1.Aggregate Functions
max,min,avg,sum,count

select * from empdemo;
select max(esal) from empdemo;--display maximum salary
select min(esal) from empdemo;---display manimum salary
select avg(esal)from empdemo;--total no of sal
select sum(esal) from empdemo;
select max(esal) HighestSal from empdemo;
select max(esal) "HighestSal" from empdemo;
select max(fname) from empdemo;
select min(fname) from empdemo;
select count(eid) from empdemo;--- count of available employee id from emp table
select count(edept) from empdemo;
select count(ecity) from empdemo;
select count(ecity) from empdemo;
select count(esal) from empdemo;--it does not count null value
select count(*) from empdemo;------It will display count of total no of table records/rows

--distinct keyword
Distinct Keyword --- How to display unique records from perticular column?
It will display unique records from perticular column.
Its not a aggregate func.

select * from empdemo;
select edept from empdemo;
select (distinct(edept)) from empdemo;
select distinct(fname) from empdemo;
How to dispay count of unique records from perticualar column?

select count(distinct(edept))from empdemo;

select count(distinct(ecity))from empdemo;

--2. Character Function
--Case Manipulation Character Manipulation
lower    length
upper    substr
initcap  instr
Q. Do you know scalar functions? ---CG
Me--- soham, I havent heard abt this terminology. Please little bit eaborate on this so i can recall if i 
have worked on it or not.
Amit- Yes snehal. these are the case related functions.
Me- okay got it. In our organization we call them as Case Manipulation functions. And lower upper
and initcap these r the functions comes under case Manipulation.

select lower(fname) from empdemo;--it convert fname to lower case 
select upper(fname) from empdemo;--it convert fname to upper case 
rollback;
select * from empdemo;
select fname,lower(fname) as Lower_Case_fname from empdemo;

select empdemo.*,lower(fname) as Lower_Case_Ename from empdemo;

select initcap(fname) from empdemo; --aMIT Amit 1st letter capital other r small
rollback
select *from empdemo;
select fname,initcap(fname) from empdemo;
select empdemo.*, initcap(fname)from empdemo; --aMIT Amit
sangharsh--- Display it in Capital letters
select upper('sangharsh') from dual;
SANGHARSH --Display it in small letters
select lower('SANGHARSH') from dual
sanghArsHa--display initial letter in capital and others in small.
select initcap('sanghArsHa') from dual
select * from dual
select upper('Vrushali'),lower('SONAM') from dual;
select * from dual;
Length--- Synatx-- length('stringname') or length(columnnane)
select * from empdemo;
select length (fname) from empdemo;
select fname, length (fname) from empdemo;
select empdemo.*, length (fname) from empdemo;

select length ('Vrushali') from dual;
select length ('Sangharsh') from dual;

Dual-- It is pseudo table/virtual table/system generated table.
Substr----Substring
It displays the specific characters from string.
substr(columnname,x,y) substr(ename,1,2)
substr('stringname',x,y)--x is strting position and y is the y is the end position
select substr('sangharsh',5,5) from dual;
select substr('Sangharsh',1,6) from dual
select substr('Sangharsh',4,4) from dual
Dual- It is Pseudo table/Virtual table
x-- starting position of char where substring starts.
y---length of substtring from that starting char(x)
select substr('Sangharsh',7,4) from dual
select substr('Sangharsh',2,5) from dual
select substr('Sangharsh',-7,4) from dual
select substr('Sangharsh',-2,5) from dual
select substr('Abhijit',5,3) from dual
select substr('Sangharsh',-7,-3) from dual---It will run, as length should not be negative value thats 
---why it will show null in result window.
select substr('Vrushali',4,5) from dual;
select substr('Vrushali',-4,3) from dual;
select substr('Vrushali',4,3),substr('Vrushali',-4,3) from dual;
select substr('Vrushali',-1,-2) from dual;---null
select substr('Sangharsh',4,4) from dual;
select substr('Sangharsh',2,4) from dual;
select substr('Sangharsh',1,3) from dual;
select fname,substr(fname,1,3) from empdemo;
select ecity,substr(ecity,1,3) from empdemo;
select fname,substr(fname,3,2) ,upper(fname) from empdemo;
select fname,substr(fname,5,3) from empdemo;--it display null value whose name less than 5 other for appropriate result
select fname,substr(fname,-5,3) from empdemo;--it display null value whose name less than 5 other for appropriate result
select fname,substr(fname,3) from empdemo; --it will select all characters from 3rd position.
select fname,substr(fname,-4) from empdemo;
select substr('Vrushali',-3) from dual;
select substr(fname,-4,-3) from empdemo;---will this work or not? Explain why--- No. Length sould not be the negative value.
--Interview QuestionTable name- Product_info---pid pname pamount address
create table product_info(pid number(5),pname varchar2(25),pamt number(7),padd varchar2(15));
drop table product_info;
--101 TV123456789LG101 80000 Pune
--102 TV198765435Samsung199 70000 Mum
--103 TV198769435Samsung201 65000 Delhi
--o/p
--123456789_101
--198765435_199
--198769435_201
insert into product_info values(101,'TV123456789LG101',80000,'pune');
insert into product_info values(102,'TV198765435Samsung199',70000,'mum');
insert into product_info values(103,'TV198769435Samsung201',65000,'delhi');
describe product_info;
alter table product_info modify(pname varchar2(26));
select * from product_info;
select substr(pname,3,9) ||'_'|| substr(pname,-3)from product_info;
--instr
select instr('Abhijit','i') from dual--it display position of that character
select instr('AbhijitAiAiuiYiTi','i',1,1) from dual--it display 

select instr('AbhijitAiAiuiYiTi','i',5,2) from dual ;--

create table emp5(eid number(5),ename varchar2(10),email varchar2(30));
insert into emp5 values(101,'snehal','sony.smane@gmail.com');

insert into emp5 values(101,'darshan','darshanmane01@yahoo.com');
select * from emp5;
--Q display user name and domain name from email in separate columan
select substr(email,1,instr(email,'@')-1) as user_name,
substr(email,instr(email,'@')+1) as domain_name from emp5 ;--

--Q display user name and domain name from email in separate columan


select instr (email,1, instr(email,'@',1,1)-1 ) from emp5;

select email, instr(email,'n',1,2)from emp5;--it count and display position of @ from starting

select email,instr(email,'@',1,1)-1 from emp5--it count & display position of @ from endside
select email,instr(email,'@')-1 from emp5--it count & display position of @ from endside

---Instr----returns the location of substring from string.

select instr('Abhijitpatil','i',5,2) from dual-- it display 2nd i position from 5th position o/p 11(5 is starting point,2 occurance)
select instr('Yusuf usman','u',3,2) from dual-- it display 2nd u from 3rd position o/p 7

select instr('Yusuf usman','u',3,3) from dual--it display 3rd u from 3rd position o/p 7
select instr('Abhijitpatil','i',3,3) from dual



select instr('yusuf', 'u',3,1) from dual

select instr('Sangsharsh','h') from dual;

select instr('Sangharsha','harsh') from dual;

select instr('Sangharsha','g') from dual;
select instr('Sangsharsh','h',1,1) from dual

select instr('Sangsharsh','h',1,2) from dual;--(1 is starting point where we want to count and  2nd occurance)
select instr('Sangsharsh','h',6,1) from dual

